var x = $("#id_unit").parent();
alert(x);