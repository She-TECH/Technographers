from django.apps import AppConfig


class SiecareAppConfig(AppConfig):
    name = 'siecareapp'
